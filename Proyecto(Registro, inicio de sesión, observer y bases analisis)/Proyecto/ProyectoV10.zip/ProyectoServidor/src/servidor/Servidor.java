/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package servidor;

import Data.AnalisisData;
import Domain.Sitio;
import GUI.JFLogging;
import java.io.IOException;
import org.jdom.JDOMException;


/**
 *
 * @author Estephanie
 */
public class Servidor {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws JDOMException, IOException {
        JFLogging logging = new JFLogging();
         logging.setVisible(true);

         
    }
    
}
