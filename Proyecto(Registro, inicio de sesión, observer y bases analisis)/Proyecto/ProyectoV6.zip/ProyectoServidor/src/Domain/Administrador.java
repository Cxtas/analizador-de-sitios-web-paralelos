/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Domain;

/**
 *
 * @author Estephanie
 */
public class Administrador extends Usuario {
    
    public Administrador(String user, String contrasenia, String tipoUsuario, boolean activo) {
        super(user, contrasenia, tipoUsuario, activo);
    }
    
    public void asignarRol(){
    
    }
    
    public void darDeBaja(){
    
    }
    
    public void darDeAlta(){
    
    }
    
}//fin clase
