/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Utility;

/**
 *
 * @author Estephanie
 */
public class Ruta {
    
    public static final String RUTAADMINISTRADOR = "administrador.xml";
    public static final String RUTAEXAMINADOR = "examinador.xml";
    public static final String RUTAURLS = "URLs.xml";
    public static final String RUTATAREAS = "tareas.xml";
}
